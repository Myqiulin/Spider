# -*- coding: utf-8 -*-
import scrapy
from ..items import SinacarItem
import time

class SinacarSpider(scrapy.Spider):
    name = 'sinacar'
    allowed_domains = ['sina.com.cn']
    start_urls = ['http://db.auto.sina.com.cn/price']

    def parse(self, response):
        """
        处理首页
        """
        # 拿到每个品牌的dl
        dl_brand = response.xpath('//div[@class="data-nav"]//ul/li/dl')
        item = SinacarItem()
        for dl in dl_brand:
            # 品牌名
            item['car_brand'] = dl.xpath('./dt[1]/a/text()').extract()[0]
            # car_link = dl.xpath('./dd/a/@href')
            car_dd = dl.xpath('./dd')
            link_del = car_dd.pop(0)
            for dd in car_dd:
                item['car_type'] = dd.xpath('./a/text()').extract()[0]
                url = "http:" + dd.xpath('./a/@href').extract()[0]
                # print item['car_type']
                # print url
                yield scrapy.Request(url=url, callback=self.parsea_detail, meta={"item": item})

    def parsea_detail(self, response):
        """
        处理详情页,获取汽车配置信息及价格
        """
        car_list = []
        li_list = response.xpath('//div[@class="config-box"]//li[@class="bd clearfix J_type_info J_certain_car"]')
        for li in li_list:

            item = response.meta["item"]
            if len(li.xpath('./div[1]/a/text()').extract()) == 0:
                item['car_configuration'] = "Null"
            else:
                item['car_configuration'] = li.xpath('./div[1]/a/text()').extract()[0]
            if len(li.xpath('./div[4]/text()').extract()) == 0:
                item['car_price'] = "Null"
            else:
                item['car_price'] = li.xpath('./div[4]/text()').extract()[0]
            car_list.append(item)
            del item

        for car in car_list:
            yield car





